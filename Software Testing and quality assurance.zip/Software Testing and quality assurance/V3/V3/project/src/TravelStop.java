package com.test.junit.junittest;

/** Represents a stop on a bus route
 *
 * Once created, it should not change.
 */
public class TravelStop {
  
	
	double latitude;
	double longitude;
	String street;
	String suburb;
	int expectedhour;
	int expectedminute;
	
  /** Create a TravelStop instance. Streets and suburbs will be checked for
   * validity by consulting an on-disk file, and an IllegalArgumentException
   * thrown if they do not exist.
   * 
   * @param latitude   Latitude of the stop
   * @param longitude  Longitude of the stop
   * @param street     Street the stop is on
   * @param suburb     Suburb the stop is in
   */
  public TravelStop(double latitude, double longitude, String street, String suburb) {

		 this.latitude = latitude;
		 this.longitude = longitude;
		 this.street = street;
		 this.suburb = suburb;
	  
  }
  
  /** 
   * @return The latitude of the stop
   */
  public double getLatitude() {
    return latitude;
  }
  
  /**
   * 
   * @return The longitude of the stop
   */
  public double getLongitude() {
    return longitude;
  }
  
  /**
   * 
   * @return The street the stop is on
   */
  public String getStreet() {
    return street;
  }
  
  /**
   * 
   * @return The suburb the stop is in
   */
  public String getSuburb() {
    return suburb;
  }

 /**
  * 
  * @return int
  */
public int getExpectedhour() {
	return expectedhour;
}

/**
 * 
 * @return int
 */
public int getExpectedminute() {
	return expectedminute;
}

  
}
