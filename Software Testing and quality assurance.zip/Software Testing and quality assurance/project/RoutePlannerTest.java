package com.test.junit.junittest;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mockito;

import junit.framework.TestCase;

/**
 * This class demonstrates how we can write route validation using Junit along
 * with mockito for user inputed latitude & longitude As stub methods provided
 * for JUnit 4 , using bellow method tools JDK 1.8 , JUnit 4.7 , Mockito 1.10 , Maven 4.0
 * <dependencies> 
 * <dependency>
 * 	<groupId>junit</groupId> 
 * 	<artifactId>junit</artifactId>
 * 	<version>4.7</version> 
 * 	<scope>test</scope> 
 * </dependency> 
 * <dependency>
 * 	<groupId>org.mockito</groupId> 
 * 	<artifactId>mockito-all</artifactId>
 * 	<version>1.10.19</version> 
 * 	<scope>test</scope>
 *  </dependency> </dependencies>
 * 
 * @author Thivahar Ajay Thennarasu
 */

public class RoutePlannerTest extends TestCase {
	
	/*
	 * declared local variables used for mocking
	 */
	RoutePlanner routeplanner;
	String[] direction = {"East Ham", "Upton Park", "Plaistow", "West Ham" , "Bromley-by-Bow" , "Bow Road" , "Mile End"};

  /**
   * @throws java.lang.Exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
	  
	  /**
	   * server.start(); or validate the server availability 
	   */
	  
	  /**
	   * DB.start(); or validate the DB server availability 
	   */
	  
	  /**
	   * Read data from a JSON File and populate DB table 
	   *     File file = new File(empTableLocation + File.separator + fileIndex + ".json");
	   *     BufferedReader inputfileTravelStops = new BufferedReader(new FileReader(file)); 
	   *     JavaDataBase.setAllStations(inputfileTravelStops)
	   */
	  
  }

  /**
   * @throws java.lang.Exception
   */
  @AfterClass
  public static void tearDownAfterClass() throws Exception {
	  /**
	   * Clear Database and set it to earlier state 
	   * JavaDataBase.setResetAllStations()
	   */
	  
	  /**
	   * stop the server : server.Stop(); and validate for stoped
	   * 
	   */
  }

  /**
   * @throws java.lang.Exception
   */
  @Before
  public void setUp() throws Exception {
	  
	  
	  /**
	   * Instantiate all other objects required for RoutePlanner test to work.
	   */
	  
	  	routeplanner = mock(RoutePlanner.class);
		System.out.println(" before test  method of class RoutePlannerTest ");
		
		
	  
	  /*
	   * success  scenarios 
	   */
		when(routeplanner.getDirections(new String[Mockito.anyInt()])).thenReturn(getAllMockedStops());
	  /*
	   * Failure scenarios 
	   */
		when(getEmptyDirection(new String[Mockito.anyInt()])).thenReturn(new IllegalArgumentException("Invalid inputs and route direction not found"));
  }

  
  /*
   * rule been used to indicate not only what exception is expected , 
   * but also the exception message expected.
   */
  @Rule
  public ExpectedException thrown = ExpectedException.none();

  
  /*   
   * If a route cannot be planned for some reason, an IllegalStateException
   * is thrown, with an explanatory message. 
   */
  private IllegalArgumentException getEmptyDirection(String dirt[]) {
	  
	  //thrown.expect(IllegalArgumentException.class);
	  //thrown.expectMessage("Due to some networking issue no route found ");
	return new IllegalArgumentException("Due to some networking issue no route found");

}

/**
   * @throws java.lang.Exception
   */
  @After
  public void tearDown() throws Exception {
	  /*
	   * resetting all the initiated objects 
	   */
	  routeplanner = null;
	  
  }

  /**
   * Test method for {@link RoutePlanner#RoutePlanner(double, double, java.lang.Integer, java.lang.Integer, double, double, java.lang.Integer, java.lang.Integer)}.
   * 
   * When the user inputs are valid then direction list would be printed 
   */
  @Test
  public void testRoutePlanner() {
	  
	  /*
	   * Success scenario
	   */
	 
	 /*
	  * Actual data coming out of the getAllStops() and java 8 lambda filter been applied 
	  * 
	  * List<TravelStop> filtered_data = getAllMockedStops().stream().filter(travel -> travel.getLatitude() == this.getStartLatitude() && travel.getLongitude() == this.getStartLongitude()).collect(Collectors.toList()).stream().filter(travel -> travel.getLatitude() == this.getDestinationLatitude() && travel.getLongitude() == this.getDestinationLatitude()).collect(Collectors.toList()); 
	  */
	  
	 
	 /*
	  * Mocked data through getAllMockedStops method
	  */
	  
	 List<TravelStop> filtered_data = routeplanner.getDirections(new String[Mockito.anyInt()]);
	  
	 //List<TravelStop> filtered_data = getAllMockedStops().stream().filter(travel -> travel.getLatitude() == this.getStartLatitude() && travel.getLongitude() == this.getStartLongitude()).collect(Collectors.toList()).stream().filter(travel -> travel.getLatitude() == this.getDestinationLatitude() && travel.getLongitude() == this.getDestinationLatitude()).collect(Collectors.toList());  

     // using lambda to iterate through collection  
     filtered_data.forEach(  
   		  travel -> System.out.println("<Stop>" + travel.getStreet()+" and <time >"+travel.getExpectedhour()+":"+travel.getExpectedminute())  
     );  
	  
	  
		/* 
		 * ----------------------------------
		 * Final result would look like bellow as JSON
		 * -----------------------------------
		 * 
		 * myroute = { 
		 * "startlocation":"East Ham", 
		 * "destinationlocation":'Mile End',
		 * "leaveHour":'13',
		 * "leaveMinute":'47',
		 * "plan": { "stops":[ "East Ham","Upton Park", "Plaistow", "West Ham" , "Bromley-by-Bow" , "Bow Road" ,"Mile End" ] , 
		 * 			{ "hours-minutes":[ "13-47", "13-58", "14-02","14-17","14-28", "14-52","15-27" ] }
		 * 		 }
		 * }
		 */
     
  }
  
  /**
   * Test method for {@link RoutePlanner#RoutePlanner(double, double, java.lang.Integer, java.lang.Integer, double, double, java.lang.Integer, java.lang.Integer)}.
   * 
   * When the user inputs are valid then direction list would be printed 
   */
  @Test
  public void testRoutePlannerScenarioTwo()  {
	  
	  /*
	   * failure scenario
	   */
	 
 	  
 	 /*
 	  * Assuming there is no route found due to some network error
 	 */
 	  
     routeplanner = mock(RoutePlanner.class);
     when(routeplanner.getDestinationLatitude()).thenReturn(-25.734968);
     when(routeplanner.getDestinationLongitude()).thenReturn(134.489563);
     
 	when(routeplanner.getDirections(new String[Mockito.anyInt()])).thenThrow(
 			new IllegalStateException("Something went wrong no route found"));
     
     
     
  }

  /**
   * Test method for {@link RoutePlanner#getStartLongitude()}.
   */
  @Test
  public void testGetStartLongitude() {
	  
		/*
		 * test whether latitude and longitude range is correct 
		 */
	    when(routeplanner.getStartLongitude()).thenReturn(0d);
	    assertTrue(" the latitude and longitude range shoule be correct  " , routeplanner.getStartLongitude() == 0);

	    fail("the latitude and longitude range shoule be correct");
  }

  
  /**
   * Test method for {@link RoutePlanner#getStartLongitude()}.
   */
  @Test
  public void testFailIfArrivalTimePassed() {
	  
    fail("Not yet implemented");
  }
  
  @Test
  public void testFailIfDepatureTimePassed() {
	  
    // assertEquals(0, );
	  
  }
  
  /**
   * Test method for {@link RoutePlanner#getStartLatitude()}.
   */
  @Test
  public void testGetStartLatitude() {
	  
	 /*
	  * Whether the StartLatitude is valid 
	  */
	  
	  routeplanner = mock(RoutePlanner.class);
	  when(routeplanner.getStartLatitude()).thenReturn(-25.734968);

	    
	 assertEquals(-25.734968, routeplanner.getStartLatitude(),0);
  }

  /**
   * Test method for {@link RoutePlanner#getLeaveHour()}.
   */
  @Test
  public void testGetLeaveHour() {
    
	 /*
	  * Whether the LeaveHour is valid 
	  * 
	  * Invalid LeaveHour scenario as it is less than current hour
	  * 
	  */
	  
  		LocalTime now = LocalTime.now();
  		int mytime = now.getHour();
	  
  		routeplanner = mock(RoutePlanner.class);
  		when(routeplanner.getLeaveHour()).thenReturn(mytime);

  		assertTrue("Invalid LeaveHour as it is less than current hour" , routeplanner.getLeaveHour().intValue()<mytime);

  }

  /**
   * Test method for {@link RoutePlanner#getLeaveMinute()}.
   */
  @Test
  public void testGetLeaveMinute() {
	  
	 /*
	  * Whether the LeaveMinute is valid 
	  * 
	  * Invalid LeaveMinute scenario 
	  */
	  
	  routeplanner = mock(RoutePlanner.class);
	  when(routeplanner.getLeaveMinute()).thenReturn(67);

	  assertTrue("Invalid Leaving minute " , routeplanner.getLeaveMinute() > 59);
    
  }

  /**
   * Test method for {@link RoutePlanner#getDestinationLongitude()}.
   */
  @Test
  public void testGetDestinationLongitude() {
		 /*
		  * Whether the DestinationLongitude is valid 
		  * 
		  * Valid DestinationLongitude scenario 
		  */
		  
		  routeplanner = mock(RoutePlanner.class);
		  when(routeplanner.getDestinationLongitude()).thenReturn(137.0230);

		  assertEquals(137.0230 , routeplanner.getLeaveMinute(),0);
  }

  /**
   * Test method for {@link RoutePlanner#getDestinationLatitude()}.
   */
  @Test
  public void testGetDestinationLatitude() {
    fail("Not yet implemented");
  }

  /**
   * Test method for {@link RoutePlanner#getArriveHour()}.
   */
  @Test
  public void testGetArriveHour() {
	  
	  
		 /*
		  * Whether the ArriveHour is valid 
		  * 
		  * Invalid ArriveHour scenario as it is less than current hour
		  */
	  		LocalTime now = LocalTime.now();
	  		int mytime = now.getHour();

				  
		  routeplanner = mock(RoutePlanner.class);
		  when(routeplanner.getArriveHour()).thenReturn(mytime);

		  assertTrue("Invalid ArriveHour  as it is less than current hour" , routeplanner.getArriveHour().intValue()<mytime);
    
  }

  /**
   * Test method for {@link RoutePlanner#getArriveMinute()}.
   */
  @Test
  public void testGetArriveMinute() {
		 /*
		  * Whether the ArriveMinute is valid 
		  * 
		  * valid ArriveMinute scenario 
		  */
				  
		  routeplanner = mock(RoutePlanner.class);
		  when(routeplanner.getArriveHour()).thenReturn(23);

		  assertEquals(23 , routeplanner.getArriveHour().intValue(),0);

  }

  /**
   * Test method for {@link RoutePlanner#getDirections()}.
   */
  @Test
  public void testGetDirections() {
	  
	  
	  	routeplanner = mock(RoutePlanner.class);
		System.out.println(" before test  method of class RoutePlannerTest ");
	  
	  /*
	   * success  scenarios 
	   */
		when(routeplanner.getDirections(new String[Mockito.anyInt()])).thenReturn(getAllMockedStops());
		
		/* 
		 * ----------------------------------
		 * Final result would look like bellow as JSON
		 * -----------------------------------
		 * 
		 * myroute = { 
		 * "startlocation":"East Ham", 
		 * "destinationlocation":'Mile End',
		 * "leaveHour":'13',
		 * "leaveMinute":'47',
		 * "plan": { "stops":[ "East Ham","Upton Park", "Plaistow", "West Ham" , "Bromley-by-Bow" , "Bow Road" ,"Mile End" ] , 
		 * 			{ "hours-minutes":[ "13-47", "13-58", "14-02","14-17","14-28", "14-52","15-27" ] }
		 * 		 }
		 * }
		 */

  }

  /**
   * As there is not database in the stack we are hard coding one single route of sydney
   * @return
   */
  public List<TravelStop> getAllStops(){
	  /*
	   * Java lambda expression can be used in the collection framework. It provides efficient and concise way to iterate, filter and fetch data
	   */
      List<TravelStop> list= Arrays.asList(   
      new TravelStop(51, -23, "East Ham", "Sydney"),
      new TravelStop(57, -21, "Upton Park", "Sydney"),  
      new TravelStop(65, -06, "Plaistow", "Sydney"),
      new TravelStop(68, -1, "West Ham", "Sydney"),
      new TravelStop(71, 4, "Bromley-by-Bow", "Sydney"),
      new TravelStop(84, 36, "Bow Road", "Sydney"),
      new TravelStop(95, 26, "Mile End", "Sydney") );
	  return list;
  }
  
  /**
   * As there is not database in the stack we are hard coding one single route of Sydney using mockito
   * @return
   */
  public List<TravelStop> getAllMockedStops(){
	  
	  /*
	   * Java lambda expression can be used in the collection framework. 
	   * It provides efficient and concise way to iterate, filter and fetch data
	   */
	  
      List<TravelStop> list= Arrays.asList(   
      new TravelStop(51, -23, "East Ham", "Sydney"),
      new TravelStop(57, -21, "Upton Park", "Sydney"),  
      new TravelStop(65, -06, "Plaistow", "Sydney"),
      new TravelStop(68, -1, "West Ham", "Sydney"),
      new TravelStop(71, 4, "Bromley-by-Bow", "Sydney"),
      new TravelStop(84, 36, "Bow Road", "Sydney"),
      new TravelStop(95, 26, "Mile End", "Sydney") );
	  return list;
  }
  
  /** Return a list of directions for the user to follow.
   * The return value is a list of TravelStop objects, which
   * will be displayed visually to the user by other classes.
   * 
   * For the description argument, an empty array of Strings should
   * be passed; an IllegalArgumentException is thrown if such an array
   * is not passed.
   * 
   * After the method is called, the method will have populated
   * this array with one String, which consists of a textual
   * description of the route to take, including walking to and from
   * or between stops.
   * 
   * If a route cannot be planned for some reason, an IllegalStateException
   * is thrown, with an explanatory message.
   * 
   */
  
  public List<TravelStop> getDirections(String description[]) {
		
      
      // using lambda to filter data  
	  // List<TravelStop> filtered_data = getAllMockedStops().stream().filter(travel -> travel.getLatitude() == this.getStartLatitude() && travel.getLongitude() == this.getStartLongitude()).collect(Collectors.toList()).stream().filter(travel -> travel.getLatitude() == this.getDestinationLatitude() && travel.getLongitude() == this.getDestinationLatitude()).collect(Collectors.toList());  
	  List<TravelStop> filtered_data =getAllMockedStops() ;
      // using lambda to iterate through collection  
      filtered_data.forEach(  
    		  travel -> System.out.println(travel.getLatitude()+": "+travel.getLongitude())  
      );  
	  
	  
    return filtered_data;
  }
  
}
