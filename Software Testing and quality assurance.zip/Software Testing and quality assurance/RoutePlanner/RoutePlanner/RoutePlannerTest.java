package com.test.junit.junittest;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.TestCase;



public class RoutePlannerTest extends TestCase {

	RoutePlanner rp1;
	RoutePlanner rp2;
	RoutePlanner rp3;
	
  /**
   * @throws java.lang.Exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
	  
	  /**
	   * server.start(); or validate the server availability 
	   */
	  
	  /**
	   * DB.start(); or validate the DB server availability 
	   */
	  
	  /**
	   * Read data from a JSON File and populate DB table 
	   *     File file = new File(empTableLocation + File.separator + fileIndex + ".json");
	   *     BufferedReader inputfileTravelStops = new BufferedReader(new FileReader(file)); 
	   *     JavaDataBase.setAllStations(inputfileTravelStops)
	   */
	  
	  
	  /**
	   * Instantiate all other objects required for RoutePlanner test to work.
	   */
	  
  }

  /**
   * @throws java.lang.Exception
   */
  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  /**
   * @throws java.lang.Exception
   */
  @Before
  public void setUp() throws Exception {
	  
	  // Pass
	  rp1 = new RoutePlanner (23,34 ,12,15 , 34,-32,00,00);
	  
	  
	  /*
	   * Failure scenarios 
	   */
	  
	 // rp1 = new RoutePlanner (23,34 ,12,15 , 34,-32,16,00);
	  
	 // rp2 = new RoutePlanner (0,0 ,12,15 , 34,-32,16,00);
	  
	  
  }

  /**
   * @throws java.lang.Exception
   */
  @After
  public void tearDown() throws Exception {
  }

  /**
   * Test method for {@link RoutePlanner#RoutePlanner(double, double, java.lang.Integer, java.lang.Integer, double, double, java.lang.Integer, java.lang.Integer)}.
   */
  @Test
  public void testRoutePlanner() {
    fail("Not yet implemented");
  }

  /**
   * Test method for {@link RoutePlanner#getStartLongitude()}.
   */
  @Test
  public void testGetStartLongitude() {
    fail("Not yet implemented");
  }

  
  /**
   * Test method for {@link RoutePlanner#getStartLongitude()}.
   */
  @Test
  public void testFailIfArrivalTimePassed() {
	  
    fail("Not yet implemented");
  }
  
  @Test
  public void testFailIfDepatureTimePassed() {
	  
    // assertEquals(0, );
	  
  }
  
  /**
   * Test method for {@link RoutePlanner#getStartLatitude()}.
   */
  @Test
  public void testGetStartLatitude() {
    fail("Not yet implemented");
  }

  /**
   * Test method for {@link RoutePlanner#getLeaveHour()}.
   */
  @Test
  public void testGetLeaveHour() {
    fail("Not yet implemented");
  }

  /**
   * Test method for {@link RoutePlanner#getLeaveMinute()}.
   */
  @Test
  public void testGetLeaveMinute() {
    fail("Not yet implemented");
  }

  /**
   * Test method for {@link RoutePlanner#getDestinationLongitude()}.
   */
  @Test
  public void testGetDestinationLongitude() {
    fail("Not yet implemented");
  }

  /**
   * Test method for {@link RoutePlanner#getDestinationLatitude()}.
   */
  @Test
  public void testGetDestinationLatitude() {
    fail("Not yet implemented");
  }

  /**
   * Test method for {@link RoutePlanner#getArriveHour()}.
   */
  @Test
  public void testGetArriveHour() {
    fail("Not yet implemented");
  }

  /**
   * Test method for {@link RoutePlanner#getArriveMinute()}.
   */
  @Test
  public void testGetArriveMinute() {
    fail("Not yet implemented");
  }

  /**
   * Test method for {@link RoutePlanner#getDirections()}.
   */
  @Test
  public void testGetDirections() {
    fail("Not yet implemented");
  }

}
