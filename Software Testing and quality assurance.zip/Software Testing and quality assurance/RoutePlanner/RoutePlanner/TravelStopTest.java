package com.test.junit.junittest;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;


	/**
	 * As the actual implementation is not in the scope but unit test in scope 
	 * used JUnit & mockitto framework to mock test data and performed JUnit
	 * testing 
	 * 
	 * It is assumed that the values of the business object set with the 
	 * values from Database in the production environment
	 * 
	 */

public class TravelStopTest {

	/*
	 * TravelStop object which is used across all tests 
	 */
	private TravelStop travelstop;
	
  /**
   * @throws java.lang.Exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
	  System.out.println("@BeforeClass: onceExecutedBeforeAll");
	  /*
	   * Is the place for us to instantiate the process to populate tables from 
	   * on-disk file from operating system location 
	   */
	  
  }

  /**
   * @throws java.lang.Exception
   */
  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  /**
   * @throws java.lang.Exception
   */
  @Before
  public void setUp() throws Exception {
	  /*
	   * Instantiate the mock to set the state of the DT class in order to test all methods 
	   */
	  	travelstop = mock(TravelStop.class);
		System.out.println(" before class ");
  }

  /**
   * @throws java.lang.Exception
   */
  @After
  public void tearDown() throws Exception {
	  /*
	   * resetting all the initiated objects 
	   */
	  travelstop = null;
 }

  /*
   * rule been used to indicate not only what exception is expected , 
   * but also the exception message expected.
   */
  @Rule
  public ExpectedException thrown = ExpectedException.none();
  
  /**
   * Test method for {@link TravelStop#TravelStop(double, double, java.lang.String, java.lang.String)}.
   */

@Test
  public void testTravelStop() {
	  
	  /*
	   * Instantiate the object TravelStop to test whether it sets the status correct
	   */
	  
	  TravelStop travelstoptest = new TravelStop(-25.734968, 134.489563, "Ghan", "Northern Territory");

	  assertEquals(-25.734968, travelstoptest.getLatitude(),0);
	  assertEquals(134.489563, travelstoptest.getLongitude(),0);
	  assertEquals("Ghan" , travelstoptest.getStreet());
	  assertEquals("Northern Territory", travelstoptest.getSuburb());
	  
  }

  
  /**
   * Test method for {@link TravelStop#getLatitude()}.
   */
  @Test
  public void testGetLatitude() {
	  
	   /*
	    * Test whether the object is null
	    */
	  travelstop = null;
	  thrown.expect(NullPointerException.class);
	  thrown.expectMessage("The travelstop is not been initiated, it is null ");

		/*
		 * test whether latitude and longitude range is correct 
		 */
	    when(travelstop.getLatitude()).thenReturn(-25.734968);
	    assertTrue(" the latitude and longitude range shoule be correct  " , travelstop.getLatitude() != 0);

    }

  /**
   * Test method for {@link TravelStop#getLongitude()}.
   */
@Test
  public void testGetLongitude() {
	    
		/*
		 * test whether latitude and longitude range is correct 
		 */
	    when(travelstop.getLongitude()).thenReturn(134.489563);
	    assertTrue(" the latitude and longitude range shoule be correct  " , travelstop.getLongitude() != 0);
  
	}

  /**
   * Test method for {@link TravelStop#getStreet()}.
   */
  @Test
  public void testGetStreet() {

	/*
	 * Test whether Streets and suburbs are Valid and 
	 * consulting an on-disk file
	 */
	  
	 /*
	  * Assuming there is no desk file
	 */
	  
    travelstop = mock(TravelStop.class);
    when(travelstop.getLatitude()).thenReturn(-25.734968);
    when(travelstop.getLongitude()).thenReturn(134.489563);
    
	when(travelstop.getStreet()).thenThrow(
			new IllegalArgumentException("Something went wrong no street found "));
    
    assertEquals("inSuburb", travelstop.getStreet());

  }

  /**
   * Test method for {@link TravelStop#getStreet()}.
   */
  @Test
  public void testStreetValidation() {
    fail("Not yet implemented");
  }
  
  /**
   * Test method for {@link TravelStop#getSuburb()}.
   */
  @Test
  public void testGetSuburb() {
	  
	  
	  /*
	   * Test whether Streets and suburbs are Valid and 
	   * consulting an on-disk file
	   */
	  
	  /*
	   * Testing happy path :  data came after consulting on-desk file
	   */
	  
		travelstop = mock(TravelStop.class);
		when(travelstop.getLatitude()).thenReturn(-25.734968);
		when(travelstop.getLongitude()).thenReturn(134.489563);
		when(travelstop.getStreet()).thenReturn("Ghan");
		when(travelstop.getSuburb()).thenReturn("Northern Territory");
	    
	    assertEquals("Northern Territory", travelstop.getSuburb());
  }

}
